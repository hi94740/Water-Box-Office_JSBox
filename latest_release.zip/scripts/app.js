var rv1Mode = false
var rv2Mode = false
var rv3Mode = false

function rv1() {
  console.log(rv1Mode)
  return rv1Mode
}

module.exports = {
  rv1:rv1,
  rv1Mode:rv1Mode,
  rv2Mode:rv2Mode,
  rv3Mode:rv3Mode
}
