exports.loadUpdateInfo = loadUpdateInfo 

function loadUpdateInfo() {
  $("fullUpdateInfo").content = $cache.get("updateInfo")
}
