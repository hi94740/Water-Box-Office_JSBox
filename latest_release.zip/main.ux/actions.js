//var mainjs = require("./main.js");
/*setTimeout(function (){
  $("mainList").scrollToOffset($cache.get("contentOffset"))
},100)*/

//"#D00A00"

if ($app.env != $env.today) {
    $("sbView").hidden = false
    $("rv2Blur").hidden = true
}

exports.notReady = notReady
exports.initML = initML
exports.backToTop = backToTop
exports.topped = topped
exports.sbTapped = sbTapped
exports.sblPressed = sblPressed
exports.rankLabelTapped = rankLabelTapped
exports.rv1Tapped = rv1Tapped
exports.rv2Tapped = rv2Tapped
exports.rv3Tapped = rv3Tapped
exports.rv1lPressed = rv1lPressed 
exports.rv2lPressed = rv2lPressed
exports.rv3lPressed = rv3lPressed
exports.selFav = selFav
exports.willSwipe = willSwipe
exports.tapToScroll = tapToScroll
exports.scrolled = scrolled

var rv1Mode = false
var rv2Mode = false
var rv3Mode = false
var boxVSshow = false
var stockMode = false
var rankChange = false
var boxChange = false
var showChange = false

var editing = false
var tappedOnce

function notReady() {
  let orz = ["诶!?(･_･;?这个功能还没准备好诶","(>﹏<)人家还没准备好这个功能啦"]
  $ui.toast(orz[Math.trunc(Math.random()*orz.length)])
}

function initML() {
  $("mainList").data = $cache.get("datacache")
  $("mainList").scrollToOffset($cache.get("contentOffset"))
  console.log($("mainList").data)
  /*if ($app.env == $env.today) {
    $("mainList").footer.height = 0
  }*/
}

function backToTop() {
  $("mainList").setEditing(false)
  editing = false
  if ($("mainList").contentOffset.y != 0) {
    $device.taptic(0)
    $("mainList").scrollToOffset($point(0, 0))
  }
  tappedOnce = 0
}
function topped(){
  console.log("topped")
  //$device.taptic(0)
}

$app.listen({
  ready:function(){
    if (true) {
      initML()
    }
  },
  initRv1:function(){
    switchBox()
  },
  initRv2:function(){
    switchRv2()
  },
  initRv3:function(){
    switchRv3()
  },
  initBvS:function(){
    switchBvS()
  },
  initSM:function(){
    console.log("initsm")
    switchSM()
  },
  initRC:function(){
    switchRC()
  },
  initBC:function(){
    console.log("sbc2")
    switchBC()
  },
  initSC:function(){
    switchSC()
  }
})

function sbTapped() {
  $device.taptic(1)
  $ui.animate({
    duration: 0.25,
    animation: function() {
      $("settingButton").rotate(Math.PI*1/3)
    },
    completion: function() {
      $device.taptic(0)
      $ui.push("settings")
      $("settingButton").rotate(0)
    }
  })
}
function sblPressed() {
  notReady()
  $device.taptic(1)
  //setTimeout(function(){$device.taptic(0)},150)
  $ui.animate({
    duration: 0.15,
    animation: function() {
      $("sbView").scale(1.5)
    },
    completion: function() {
      $device.taptic(0)
      $ui.animate({
          duration: 0.15,
          animation: function() {
            $("sbView").scale(1)
          },
          completion: function() {

          }
        })
    }
  })
}

function rankLabelTapped() {
  if (stockMode) {
    $device.taptic(0)
    switchRC()
  }
}
function rv1Tapped() {
  $device.taptic(1)
  switchBox()
}
function rv2Tapped() {
  $device.taptic(0)
  if (stockMode) {
    switchBC()
  } else {
    switchRv2()
  }
}
function rv3Tapped() {
  $device.taptic(0)
  if (stockMode) {
    switchSC()
  } else {
    switchRv3()
  }
}

function rv1lPressed(){
  console.log("???")
  //$ui.toast($addin.current.url)
  /*$device.taptic(1)
  setTimeout(function(){$device.taptic(1);$app.openURL("jsbox://run?name=" + encodeURIComponent($addin.current.name))},100)*/
  rv3lPressed()
  //$addin.run("票房")
}
function rv2lPressed() {
  if (((rv2Mode == false) && stockMode == false) || (boxChange == false) && stockMode) {
    if (boxVSshow) {
      $ui.toast("❎加粗  票房 > 排片")
    } else {
      $ui.toast("✅加粗  票房 > 排片")
    }
    $device.taptic(0)
    switchBvS()
    setTimeout(function(){$device.taptic(0)},100)
  }
}
function rv3lPressed() {
  console.log(stockMode)
  if (stockMode) {
    $ui.toast("❎关闭 💹股票模式")
  } else {
  $ui.toast("✅开启 💹股票模式")
  }
  $device.taptic(1)
  switchSM()
  setTimeout(function(){$device.taptic(0)},100)
}

function switchBox() {
  //console.log("tapped")
  if (rv1Mode){
    rv1Mode = false
    $("rhl1").text = "当日票房/万"
    //console.log(rv1Mode)
  } else {
    rv1Mode = true
    $("rhl1").text = "总票房"
    //console.log(rv1Mode)
  }
  $app.notify({
    name: "switchBox",
    object: rv1Mode
  });
}

function switchRv2() {
  if (rv2Mode){
    rv2Mode = false
    $("rhl2").text = "票房占比"
  } else {
    rv2Mode = true
    $("rhl2").text = "上座率"
  }
  $app.notify({
    name: "switchRv2",
    object: rv2Mode
  });
}

function switchRv3() {
  if (rv3Mode){
    rv3Mode = false
    $("rhl3").text = "排片占比"
  } else {
    rv3Mode = true
    $("rhl3").text = "排片量/场"
  }
  $app.notify({
    name: "switchRv3",
    object: rv3Mode
  });
}

function switchBvS() {
  if (boxVSshow){
    boxVSshow = false
  } else {
    boxVSshow = true
  }
  $app.notify({
    name: "switchBvS",
    object: boxVSshow
  });
}

function switchSM() {
  if (stockMode){
    stockMode = false
    if (rv2Mode) {
      $("rhl2").text = "上座率"
    } else {
      $("rhl2").text = "票房占比"
    }
    if (rv3Mode) {
      $("rhl3").text = "排片量/场"
    } else {
      $("rhl3").text = "排片占比"
    }
  } else {
    stockMode = true
    if (boxChange) {
      $("rhl2").text = "对比昨天"
    } else {
      $("rhl2").text = "票房占比"
    }
    if (showChange) {
      $("rhl3").text = "明日变化"
    } else {
      $("rhl3").text = "排片占比"
    }
  }
  $app.notify({
    name: "switchSM",
    object: stockMode
  });
}
function switchRC() {
  if (rankChange){
    rankChange = false
  } else {
    rankChange = true
  }
  $app.notify({
    name: "switchRC",
    object: rankChange
  });
}
function switchBC() {
  if (stockMode) {
    if (boxChange == true){
      boxChange = false
      $("rhl2").text = "票房占比"
    } else {
      boxChange = true
      $("rhl2").text = "对比昨天"
    }
  }
  $app.notify({
    name: "switchBC",
    object: boxChange
  });
}
function switchSC() {
  if (stockMode) {
    if (showChange == true){
      showChange = false
      $("rhl3").text = "排片占比"
    } else {
      showChange = true
      $("rhl3").text = "明日变化"
    }
  }
  $app.notify({
    name: "switchSC",
    object: showChange
  });
}

function selFav(info/*sender, indexPath, data*/) {
  notReady()
  $device.taptic(2)
  let id = info.sender.views[1].info
  console.log(id)
  //console.log(info.location)
  //$("mainList").setEditing(true)
  //editing = true
}
function willSwipe(){
  $ui.toast("阿咧 Σ（・□・；）这都被你发现了")
  $app.notify({name:"pause5s"})
  return true
}

function tapToScroll(sender, indexPath, data) {
  if ($app.env == $env.today) {
    $device.taptic(0)
    //$ui.toast(tappedOnce)
    if (tappedOnce == indexPath.row) {
      $app.openURL("jsbox://run?name=" + encodeURIComponent($addin.current.name))
    } else {
      //$ui.toast(tappedOnce)
      tappedOnce = indexPath.row
      //$ui.toast(tappedOnce)
      if (indexPath.row < 1){
        //backToTop()
      } else {
        $("mainList").scrollToOffset($point(0, (indexPath.row - 1) * 44))
      }
    }
  } else {
    /*$ui.preview({
      title: "第" + data.rankLabel.text + "名",
      url: "https://piaofang.maoyan.com/movie/" + data.titleLabel.info
    })*/
    $ui.push("web.ux")
    $("web[0]").url = "https://piaofang.maoyan.com/movie/" + data.titleLabel.info
    $ui.title = "第" + (indexPath.row + 1) + "名"
  }
}

function scrolled(){
  //console.log($("mainList").contentOffset)
  $cache.set("contentOffset",$("mainList").contentOffset)
}
