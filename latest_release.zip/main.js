//var app = require("./scripts/app")
//var mainux = require("./main.ux")

$ui.render("main");

var notInit = false
var rawData
var yestrData
var tomorData
//var todayDict = []
var yestDict = []
var tomoDict = []
var data = []

var pause = false
var pause5sCount
var pause5sCounting = false

var rv1Mode = false
var rv2Mode = false
var rv3Mode = false
var boxVSshow = $cache.get("boxVSshow")
var stockMode = $cache.get("stockMode")
var rankChange = false
var boxChange = false
var showChange = false

var releaseColorMode = $cache.get("releaseColorMode")
var reverseColorMode = $cache.get("reverseColorMode")

function upColor() {
  if (reverseColorMode) {
    return $color("#FF3B30")
  } else {
    return $color("#4CD964")
  }
}
function downColor() {
  if (reverseColorMode) {
    return $color("#4CD964")
  } else {
    return $color("#FF3B30")
  }
}

$app.listen({
  ready: function() {
    
  },
  pause: function() {
    //pause = true
  },
  unpause: function() {
    pause = false
  },
  pause5s: function() {
    pause5sCount = new Date().getTime()
    pause = true
    pause5sCounting = true
  },
  
  switchBox: function(object) {
    rv1Mode = object
    if (notInit) {
      MLupdate()
      $cache.set("rv1",object)
    }
  },
  switchRv2: function(object) {
    rv2Mode = object
    if (notInit) {
      MLupdate()
      $cache.set("rv2",object)
    }
  },
  switchRv3: function(object) {
    rv3Mode = object
    if (notInit) {
      MLupdate()
      $cache.set("rv3",object)
    }
  },
  switchBvS: function(object) {
    boxVSshow = object
    if (notInit) {
      MLupdate()
      $cache.set("boxVSshow",object)
    }
  },
  switchReleaseColor: function() {
    releaseColorMode = !releaseColorMode
    if (notInit) {
      MLupdate()
      $cache.set("releaseColorMode",releaseColorMode)
    }
  },
  switchReverseColor: function() {
      reverseColorMode = !reverseColorMode
      if (notInit) {
        MLupdate()
        $cache.set("reverseColorMode",reverseColorMode)
      }
    },
  switchSM: function(object) {
    stockMode = object
    if (notInit) {
      MLupdate()
      $cache.set("stockMode",object)
    }
  },
  switchRC: function(object) {
    rankChange = object
    if (notInit) {
      MLupdate()
      $cache.set("rankChange",object)
    }
  },
  switchBC: function(object) {
    console.log("sbc")
    boxChange = object
    if (notInit) {
      MLupdate()
      $cache.set("boxChange",object)
    }
  },
  switchSC: function(object) {
    showChange = object
    if (notInit) {
      MLupdate()
      $cache.set("showChange",object)
    }
  }
});

if (releaseColorMode == undefined) {
  $cache.set("releaseColorMode",true)
  releaseColorMode = true
}
if (reverseColorMode == undefined) {
  $cache.set("reverseColorMode",false)
  reverseColorMode = false
}
if (boxVSshow == undefined) {
  $cache.set("boxVSshow",false)
  boxVSshow = false
}
if (stockMode == undefined) {
  $cache.set("stockMode",false)
  stockMode = false
}

if($cache.get("rv1") == true) {
  $app.notify({
    name:"initRv1"
  })
}
if($cache.get("rv2") == true) {
  $app.notify({
    name:"initRv2"
  })
}
if($cache.get("rv3") == true) {
  $app.notify({
    name:"initRv3"
  })
}
if(boxVSshow == true) {
  $app.notify({
    name:"initBvS"
  })
}
if(stockMode == true) {
  console.log("???initsm")
  $app.notify({
    name:"initSM"
  })
}
if($cache.get("rankChange") == true) {
  console.log("??!")
  $app.notify({
    name:"initRC"
  })
}
if($cache.get("boxChange") == true) {
  $app.notify({
    name:"initBC"
  })
}
if($cache.get("showChange") == true) {
  $app.notify({
    name:"initSC"
  })
}

function perChange(p1,p2) {
  let p1n = p1.replace("%","").replace("<","") - 0.01
  let p2n = p2.replace("%","").replace("<","") - 0.01
  let pn = p1n - p2n
  let sign = ""
  if (pn > 0) {
    sign = "+"
  }
  let p11 = p1.startsWith("<")
  let p21 = p2.startsWith("<")
  if ((p11 == false) && p21) {
    if (pn == 0) {
      return "+<0.1%"
    } else {
      return sign + pn.toFixed(1) + "%"
    }
  } else if (p11 && (p21 == false)) {
    if (pn == 0) {
      return "-<0.1%"
    } else {
      return sign + pn.toFixed(1) + "%"
    }
  } else if (p11 && p21) {
    return "<0.1%"
  } else {
    return sign + pn.toFixed(1) + "%"
  }
}
function perMap(p1,p2) {
  let p1n = p1.replace("%","").replace("<","") - 0.01
  let p2n = p2.replace("%","").replace("<","") - 0.01
  let pn = Math.abs(p1n - p2n)
  let sign = Math.sign(p1n - p2n)
  let p11 = p1.startsWith("<")
  let p21 = p2.startsWith("<")
  if (pn >= 10) {
    return ((pn - 10)*(0.4/90) + 0.6) * sign
  } else if (pn >= 1) {
    return ((pn - 1)*(0.3/9) + 0.3) * sign
  } else if (p11||p21) {
    if ((p11 == false) && p21) {
      return 0.1
    } else if ((p21 == false) && p11) {
      return -0.1
    } else {
      return 0
    }
  } else {
    return (pn * 0.2 + 0.1) * sign
  }
}

function MLupdate(){
  //noUndefined()
  if (rawData == undefined){
    let cachedRawData = $cache.get("rawData")
    if (cachedRawData == undefined){
      //$("loadingLabel").hidden = false
      //$ui.loading(true)
      rawData = {}
    } else {
      rawData = cachedRawData 
    }
  }
  if (yestrData == undefined){
    let cachedRawData = $cache.get("yestrData")
    if (cachedRawData == undefined){
      yestrData = {}
      updateYestrData()
    } else {
      yestrData = cachedRawData
      updateYestDict()
    }
  }
  if (tomorData == undefined){
    let cachedRawData = $cache.get("tomorData")
    if (cachedRawData == undefined){
      tomorData = {}
      updateTomorData()
    } else {
      tomorData = cachedRawData
      updateTomoDict()
    }
  }
  let MLdata = rawData.list
  for (let i in MLdata){
    //console.log(MLdata[i].movieName)
    //todayDict = []
    //todayDict[MLdata[i].movieId + ""] = MLdata[i]
    
    let rl1
    let rl2
    let rl3
    //console.log(mainux.rv1())
    if (rv1Mode == false){
      rl1 = MLdata[i].boxInfo
    } else {
      rl1 = MLdata[i].sumBoxInfo
    }
    if ((rv2Mode == false)||stockMode){
      rl2 = MLdata[i].boxRate
    } else if (stockMode == false) {
      rl2 = MLdata[i].avgSeatView
    }
    if ((rv3Mode == false)||stockMode){
      rl3 = MLdata[i].showRate
    } else if (stockMode == false) {
      rl3 = MLdata[i].showInfo
    }
    let rank = i - 1 + 2
    let releaseColor
    if (releaseColorMode) {
      releaseColor = $color(MLdata[i].releaseInfoColor.slice(0,7))
    } else {
      releaseColor = $color("#666666")
    }
    data[i] = {
      rankLabel:{
        text:"" + rank,
        font:$font("Menlo-BoldItalic",21)
      },
      rankBg:{
        hidden:true
      },
      titleLabel:{
        text:MLdata[i].movieName,
        info:MLdata[i].movieId
      },
      releaseLabel:{
        text:MLdata[i].releaseInfo,
        textColor:releaseColor
      },
      rl1:{
        text:rl1
      },
      rl2:{
        text:rl2
      },
      rv2bg:{
        hidden:true
      },
      rl3:{
        text:rl3
      },
      rv3bg:{
        hidden:true
      },
      rv3Blur:{
        hidden:true
      }
    }
    if (rl1.endsWith("亿")) {
      data[i].rl1.font = $font("Iosevka-Bold",19)
    } else {
      data[i].rl1.font = $font("Iosevka",19)
    }
    if (!rv1Mode) {
      data[i].rl1.alpha = 0.9 - rank/100
    }
    let milestone = MLdata[i].milestone
    console.log(milestone)
    if (milestone != undefined) {
      if (releaseColorMode) {
        data[i].releaseLabel.textColor = $color("#FF3B30")
      }
      data[i].releaseLabel.text = data[i].releaseLabel.text + " " + milestone.boxCopy
    }
    let bvsf1 = (boxVSshow == true) && (((rv2Mode == false) && (stockMode == false))||((boxChange == false) && stockMode))
    let bvsf2 = MLdata[i].boxRate.replace("%","").replace("<","") - 0.01 > MLdata[i].showRate.replace("%","").replace("<","") - 0.01
    let bvsf3 = (MLdata[i].boxRate.startsWith("<") == false) && (MLdata[i].showRate.startsWith("<"))
    if ((bvsf2 || bvsf3) && bvsf1) {
      data[i].rl2.font = $font("AvenirNextCondensed-Bold",15)
      data[i].rl2.textColor = $color("#111111")
      //data[i].rv2bg.bgcolor = upColor()
      //data[i].rv2bg.hidden = false
    } else {
      data[i].rl2.font = $font("AvenirNextCondensed-Medium",16)
      data[i].rl2.textColor = $color("#333333")
      //data[i].rv2bg.hidden = true
    }
    if (stockMode) {
      data[i].rv3Blur.hidden = false
      data[i].rv2bg.hidden = false
      data[i].rv3bg.hidden = false
      let yestItem = yestDict["" + MLdata[i].movieId]
      let tomoItem = tomoDict["" + MLdata[i].movieId]
      if (rankChange) {
        data[i].rankLabel.font = $font("GillSans",21)
      }
      if (yestItem == undefined) {
        data[i].rv2bg.alpha = 0
        //console.log(i + “  “ + undefined)
        data[i].rankBg.hidden = false
        if (rank <= 15) {
          data[i].rankBg.alpha = 1
        } else {
          data[i].rankBg.alpha = (21 - rank) / 5
        }
        data[i].rankBg.bgcolor = upColor()
        if (boxChange) {
          data[i].rl2.text = "N/A"
        }
        if (rankChange) {
          data[i].rankLabel.text = "new"
        }
      } else {
        data[i].rankBg.hidden = false
        let rankChangeV = yestItem.rank - rank
        let absrcv = Math.abs(rankChangeV)
        if (absrcv > 5) {
          data[i].rankBg.alpha = 1
        } else {
          data[i].rankBg.alpha = absrcv / 5
        }
        if (rankChangeV < 0) {
          data[i].rankBg.bgcolor = downColor()
        } else {
          data[i].rankBg.bgcolor = upColor()
        }
        if (rankChange) {
          if (rankChangeV > 0) {
            if (absrcv == 1) {
              data[i].rankLabel.text = "↑"
            } else if (absrcv == 2) {
              data[i].rankLabel.text = "⇈"
            } else {
              data[i].rankLabel.text = "↟" + absrcv
            }
          } else if (rankChangeV < 0) {
            if (absrcv == 1) {
              data[i].rankLabel.text = "↓"
            } else if (absrcv == 2) {
              data[i].rankLabel.text = "⇊"
            } else {
              data[i].rankLabel.text = "↡" + absrcv
            }
          } else {
            //data[i].rankLabel.text = "-"
            data[i].rankLabel.font = $font("Menlo-BoldItalic",21)
          }
        }
        
        let rv2bga = perMap(MLdata[i].boxRate,yestItem.boxRate)
        //console.log(i + “  “ + rv2bga)
        if (rv2bga < 0) {
          data[i].rv2bg.bgcolor = downColor()
          data[i].rv2bg.alpha = Math.abs(rv2bga)
        } else {
          data[i].rv2bg.bgcolor = upColor()
          data[i].rv2bg.alpha = rv2bga
        }
        if (boxChange) {
          console.log("boxperchange " + boxChange)
          data[i].rl2.text = perChange(MLdata[i].boxRate,yestItem.boxRate)
        }
      }
      data[i].rankBg.alpha = data[i].rankBg.alpha * ((21 - rank) * 0.5 / 20 +0.5)
      if (tomoItem == undefined) {
        data[i].rv3bg.alpha = 0
        if (showChange) {
          data[i].rl3.text = "N/A"
        }
      } else {
        let rv3bga = perMap(tomoItem.showRate,MLdata[i].showRate)
        if (rv3bga < 0) {
          data[i].rv3bg.bgcolor = downColor()
          data[i].rv3bg.alpha = Math.abs(rv3bga)
       } else {
          data[i].rv3bg.bgcolor = upColor()
          data[i].rv3bg.alpha = rv3bga
       }
       /*if (rv3bga == 0) {
         data[i].rv3Blur.hidden = true
       }*/
       if (showChange) {
         data[i].rl3.text = perChange(tomoItem.showRate,MLdata[i].showRate)
        }
      }
    }
  }
  $("mainList").data = data
  $cache.set("datacache",data)
}
function latencyUpdate() {
  //noUndefined()
  if (rawData == undefined){
    let cachedRawData = $cache.get("rawData")
    if (cachedRawData == undefined){
      //$("loadingLabel").hidden = false
      //$ui.loading(true)
      rawData = {}
    } else {
      rawData = cachedRawData 
    }
  }
  let now = new Date()
  let latency = ((now.getTime() - rawData.serverTimestamp)/60000).toFixed(0)
  //latency = 20
  if (latency == 0){
    $("thLabel").text = rawData.serverTime
    $("thLabel").textColor = $color("#333333")
  } else {
    $("thLabel").text = "更新于" + latency + "分钟前"
    $("thLabel").textColor = $color("#FF3B30")
    if ((latency/60).toFixed(0) > 0) {
      $("thLabel").text = "更新于" + (latency/60).toFixed(0) + "小时前"
    }
    if ((latency/1440).toFixed(0) > 0) {
          $("thLabel").text = "更新于" + (latency/1440).toFixed(0) + "天前"
    }
  }
}

//MLupdate()
latencyUpdate()
//iLoop()
setTimeout(function(){
  iLoop()
  notInit = true
},100)
setInterval(iLoop,2000)

function iLoop() {
  if (pause == false) {
    $http.get({
      url: "https://box.maoyan.com/promovie/api/box/second.json",
      handler: function(resp) {
        //console.log("loophttp")
        rawData = resp.data.data
        latencyUpdate()
        MLupdate()
        
        //$("loadingLabel").hidden = true
        //$ui.loading(false)
        $cache.set("rawData",rawData)
      }
    })
    updateTomorData()
    let uydf0 = true
    if (yestrData == undefined){
      let cachedRawData = $cache.get("yestrData")
      if (cachedRawData == undefined){
        yestrData = {}
        updateYestrData()
        uydf0 = false
      } else {
        yestrData = cachedRawData
        updateYestDict()
      }
    }
    if (uydf0) {
      let yestrDate = new Date(yestrData.serverTimestamp)
      let now = new Date()
      if (((now.getTime() - yestrData.serverTimestamp) > 86400000)||now.getDate() != yestrDate.getDate()) {
        updateYestrData()
      }
    }
  }
  if ((new Date().getTime() - pause5sCount) >= 5000 && pause5sCounting) {
    pause = false
    pause5sCounting = false
  }
}

function autoZero(num) {
  if(num < 10){
    return "0" + num
  } else {
    return "" + num
  }
}
function updateTomorData() {
  let nowInt = new Date().getTime()
  let tomorrow = new Date(nowInt + 86400000)
  let tomorrowUrl = "https://box.maoyan.com/promovie/api/box/second.json?beginDate=" + tomorrow.getFullYear() + autoZero(tomorrow.getMonth() + 1) + autoZero(tomorrow.getDate())
  $http.get({
    url: tomorrowUrl,
    handler: function(resp) {
      tomorData = resp.data.data
      $cache.set("tomorData",tomorData)
      updateTomoDict()
    }
  })
}
function updateYestrData() {
  let nowInt = new Date().getTime()
  let yesterday = new Date(nowInt - 86400000)
  let yesterdayUrl = "https://box.maoyan.com/promovie/api/box/second.json?beginDate=" + yesterday.getFullYear() + autoZero(yesterday.getMonth() + 1) + autoZero(yesterday.getDate())
  $http.get({
    url: yesterdayUrl,
    handler: function(resp) {
      yestrData = resp.data.data
      $cache.set("yestrData",yestrData)
      updateYestDict()
      //console.log("yesterday")
    }
  })
}

function updateTomoDict() {
  tomoDict = []
  let tomoList = tomorData.list
  for (let i in tomoList) {
    tomoList[i].rank = i - 1 + 2
    tomoDict["" + tomoList[i].movieId] = tomoList[i]
  }
}
function updateYestDict() {
  yestDict = []
  let yestList = yestrData.list
  for (let i in yestList) {
    yestList[i].rank = i - 1 + 2
    yestDict["" + yestList[i].movieId] = yestList[i]
  }
}

