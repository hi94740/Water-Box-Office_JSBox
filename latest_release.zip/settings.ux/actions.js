exports.tapRow = tapRow
exports.loadSettings = loadSettings
exports.rowHeight = rowHeight
exports.smTapped = smTapped
exports.uc1Changed = uc1Changed
exports.RCchanged = RCchanged
exports.RC2changed = RC2changed
exports.BvSchanged = BvSchanged
exports.smChanged = smChanged

var version = $addin.current.version
var updateString = "尚未检查更新" 

var releaseColorMode = false
var reverseColorMode = false
var boxVSshow = false
var stockMode = false

function checkUpdate() {
  updateString = "正在检查更新"
  loadSettings()
  $http.get({
    url:"https://raw.githubusercontent.com/hi94740/Water-Box-Office_JSBox/master/latest_version",
    handler: function(resp) {
      let latestVersion = resp.data.replace("\n","")
      if (latestVersion == version) {
        updateString = "已是最新版本"
      } else if (latestVersion != "") {
        updateString = "有新版本："+latestVersion
      }
      loadSettings()
    }
  })
}

function tapRow(sender,indexPath,data) {
  if (data.info == "checkUpdate") {
    checkUpdate()
  }
}

function reverseColorSetting() {
  let upColor
  let downColor
  if (reverseColorMode) {
    upColor = $color("#FF3B30")
    downColor = $color("#4CD964")
  } else {
    upColor = $color("#4CD964")
    downColor = $color("#FF3B30")
  }
  return {
    info:"",
    reverseColorSetting:{
      hidden:false
    },
    upColor:{bgcolor:upColor},
    downColor:{bgcolor:downColor}
  }
}

function rowHeight() {
  console.log("rowheight")
  if ($("stockMode").on) {
    return 88
  } else {
    return 44
  }
}

function smTapped() {
  $ui.action({
    title: "Hello",
    message: "World",
    actions: [
      {
        title: "OK",
        disabled: false, // Optional
        handler: function() {
  
        }
      },
      {
        title: "Cancel",
        handler: function() {
  
        }
      }
    ]
  })
}

function uc1Changed(sender) {
  if (sender.info == "stockMode") {
    smChanged()
  }
}

function RCchanged() {
  $app.notify({name:"switchReleaseColor"})
  setTimeout(loadSettings,300)
}
function RC2changed() {
  $app.notify({name:"switchReverseColor"})
  setTimeout(loadSettings,100)
  $device.taptic(0)
}
function BvSchanged() {
  $app.notify({name:"initBvS"})
  setTimeout(loadSettings,300)
}
function smChanged() {
  if (stockMode) {
    $("settingList").delete($indexPath(0,3))
  } else {
    $("settingList").insert({
      indexPath: $indexPath(0, 3),
      value: reverseColorSetting()
    })
  }
  $app.notify({name:"initSM"})
  stockMode = !stockMode
}

function loadSettings() {
  releaseColorMode = $cache.get("releaseColorMode")
  reverseColorMode = $cache.get("reverseColorMode")
  boxVSshow = $cache.get("boxVSshow")
  stockMode = $cache.get("stockMode")
  console.log("SMsetting " + stockMode)
  let bvssl02font
  let rcmsl11color
  let rcmsl12color
  if (releaseColorMode) {
    rcmsl11color = $color("#FF9900")
    rcmsl12color = $color("#FF3B30")
  } else {
    rcmsl11color = $color("#888888")
    rcmsl12color = $color("#888888")
  }
  if (boxVSshow) {
    bvssl02font = $font("PingFangSC-Semibold",17)
  } else {
    bvssl02font = $font("PingFangSC-Light",17)
  }
  //$("settingList").data = {}
  let data = [
    {
      title: "主界面设置",
      rows: [
        {
          info:"",
          rcSetting:{
            hidden:false
          },
          releaseColorMode:{
            on:releaseColorMode
          },
          rcLabel11:{
            textColor:rcmsl11color
          },
          rcLabel12:{
            textColor:rcmsl12color
          }
        },
        {
          info:"",
          BvSsetting:{
            hidden:false
          },
          boxVSshow:{
            on:boxVSshow
          },
          BvSsLabel02:{
            font:bvssl02font
          }
        },
        {
          info:"",
          uniCell1:{
            hidden:false
          },
          uc1Title:{
            text:"股票模式"
          },
          uc1Subtitle:{
            text:"长按主界面 第三栏 和 最右一栏 可快速开关"
          },
          uc1Switch:{
            on:stockMode,
            info:"stockMode"
          }
        }
      ]
    },
    {
      title:"版本更新",
      rows:[
        {
          info:"checkUpdate",
          uniCell0:{hidden:false},
          uc0Title:{text:"点击检查更新"},
          uc0Subtitle:{text:"当前版本：" + version},
          uc0Detail:{text:updateString}
        }
      ]
    }
   ]
   if (stockMode) {
     data[0].rows[3] = reverseColorSetting()
   }
   $("settingList").data = data
}
