exports.tapRow = tapRow
exports.loadSettings = loadSettings
exports.rowHeight = rowHeight
exports.smTapped = smTapped
exports.uc1Changed = uc1Changed
exports.RCchanged = RCchanged
exports.RC2changed = RC2changed
exports.BvSchanged = BvSchanged
exports.smChanged = smChanged
exports.updateInfoTapped = updateInfoTapped
exports.updateTapped = updateTapped
exports.installTapped = installTapped

var version = $addin.current.version
var updateString = "尚未检查更新"
var downloading = false

var releaseColorMode = false
var reverseColorMode = false
var boxVSshow = false
var stockMode = false
var updateAvailable = false
var updateInfo = "**正在加载更新说明……**"
function updateInfoCell() {
  if (downloading) {
    return {
      info:"updateInfo",
      updateInfoCell:{hidden:false},
      updateInfo:{content:updateInfo},
      updateProgressBar:{alpha:1},
      updateButton:{hidden:true},
      updateProgressB:{alpha:1},
      updateProgressW:{alpha:1}
    }
  }
  if (updateData != undefined) {
    return {
      info:"updateInfo",
      updateInfoCell:{hidden:false},
      updateInfo:{content:updateInfo},
      updateProgressBar:{alpha:0},
      updateButton:{hidden:true},
      updateProgressB:{alpha:0},
      updateProgressW:{alpha:0},
      installButton:{hidden:false}
    }
  }
  return {
    info:"updateInfo",
    updateInfoCell:{hidden:false},
    updateInfo:{content:updateInfo}
    }
}
var loadedVersion
function checkUpdate() {
  updateString = "正在检查更新"
  loadSettings()
  $http.get({
    url:"https://raw.githubusercontent.com/hi94740/Water-Box-Office_JSBox/master/latest_version",
    handler: function(resp) {
      let latestVersion = resp.data.replace("\n","")
      if (latestVersion == version) {
        updateString = "已是最新版本"
        loadSettings()
      } else if (latestVersion != "") {
        if (loadedVersion != latestVersion) {
          updateData = undefined
          loadedVersion = latestVersion
        }
        updateString = "🔴 有新版本"
        loadSettings()
        updateInfo = "### " + latestVersion + "\n" + "**正在加载更新说明……**"
        $device.taptic(0)
              setTimeout(function(){$device.taptic(0)},150)
        console.log(updateAvailable)
        
          if (!updateAvailable) {
            setTimeout(function() {
            $("settingList").insert({
            indexPath:$indexPath(1,2),
            value:updateInfoCell()
        })},100)}
        console.log("1st")
        updateAvailable = true
        $http.get({
          url:"https://raw.githubusercontent.com/hi94740/Water-Box-Office_JSBox/master/update_info.md",
          handler: function(resp) {
            $delay(1,function() {
              updateInfo = resp.data
              loadSettings()
            })
            //updateInfo = resp.data
            //loadSettings()
            //setTimeout(loadSettings,200)
            console.log("2nd")
          }
        })
      }
      //setTimeout(loadSettings,500)
    }
  })
}

var proportion = 0
var progressBarValue = 0
var upbID
function setProgressBar() {
  $("updateProgressBar").value = progressBarValue
  $("updateProgressWView").updateLayout(function(make,view){
    make.width.equalTo(progressBarValue * 100)
  })
}
function updateProgressBar() {
  if (proportion > progressBarValue) {
    let diff = proportion - progressBarValue
    if (diff >= 0.02) {
      progressBarValue = progressBarValue + (diff - 0.01) / 2
    } else {
      progressBarValue = progressBarValue + 0.01
    }
    setProgressBar()
  } else {
    clearInterval(upbID)
    upbID = undefined
  }
}
var updateData
function progress() {
  console.log("proportion:" + proportion)
  if (upbID == undefined) {
          upbID = setInterval(updateProgressBar,16)
        }
        let percentage = (proportion * 100).toFixed(0) + "%"
        $("updateProgressB").text = percentage
        $("updateProgressW").text = percentage
}
function update() {
  downloading = true
  $http.download({
    url:"https://raw.githubusercontent.com/hi94740/Water-Box-Office_JSBox/master/latest_release.zip",
    showsProgress:false,
    progress:function(bytesWritten,totalBytes) {
      proportion = (bytesWritten/totalBytes).toFixed(2)
      progress()
    },
    handler:function(resp) {
      $device.taptic(1)
      setTimeout(function(){$device.taptic(0)},150)
      downloading = false
      updateData = resp.data
      $("installButton").hidden = false
      $ui.animate({
        duration:0.5,
        animation:function() {
          $("updateProgressB").alpha = 0
          $("updateProgressW").alpha = 0
        },
        completion:function() {
          $ui.animate({
            duration:0.5,
            animation:function() {
              $("updateProgressBar").alpha = 0
            },
            completion:function() {
              
            }
          })
        }
      })
    }
  })
}

function tapRow(sender,indexPath,data) {
  console.log("tapped")
  if (data.info == "checkUpdate") {
    $device.taptic(0)
    checkUpdate()
  }
  if (data.info == "updateInfo") {
    $cache.set("updateInfo",updateInfo)
    updateInfoTapped()
  }
}

function reverseColorSetting() {
  let upColor
  let downColor
  if (reverseColorMode) {
    upColor = $color("#FF3B30")
    downColor = $color("#4CD964")
  } else {
    upColor = $color("#4CD964")
    downColor = $color("#FF3B30")
  }
  return {
    info:"",
    reverseColorSetting:{
      hidden:false
    },
    upColor:{bgcolor:upColor},
    downColor:{bgcolor:downColor}
  }
}

function rowHeight(sender,indexPath) {
  if (indexPath == $indexPath(1,2)){
    return 233
  } else {
    return 45
  }
}

function smTapped() {
  $ui.action({
    title: "Hello",
    message: "World",
    actions: [
      {
        title: "OK",
        disabled: false, // Optional
        handler: function() {
  
        }
      },
      {
        title: "Cancel",
        handler: function() {
  
        }
      }
    ]
  })
}

function uc1Changed(sender) {
  if (sender.info == "stockMode") {
    smChanged()
  }
}

function RCchanged() {
  $app.notify({name:"switchReleaseColor"})
  setTimeout(loadSettings,300)
}
function RC2changed() {
  $app.notify({name:"switchReverseColor"})
  setTimeout(loadSettings,100)
  $device.taptic(0)
}
function BvSchanged() {
  $app.notify({name:"initBvS"})
  setTimeout(loadSettings,300)
}
function smChanged() {
  if (stockMode) {
    $("settingList").delete($indexPath(0,3))
  } else {
    $("settingList").insert({
      indexPath: $indexPath(0, 3),
      value: reverseColorSetting()
    })
  }
  $app.notify({name:"initSM"})
  stockMode = !stockMode
  $("settingList").remakeLayout()
}

function updateInfoTapped() {
  console.log("uitapped")
  $ui.push("updateInfo.ux")
}

function updateTapped() {
  $device.taptic(0)
  //$delay(1,function(){
  $ui.animate({
    duration:0.5,
    animation:function() {
      $("updateProgressBar").alpha = 1
      //$("updateButton").alpha = 0
    },
    completion:function() {
      $("updateButton").hidden = true
      $ui.animate({
        duration:0.5,
        animation:function() {
          $("updateProgressB").alpha = 1
          $("updateProgressW").alpha = 1
        },
        completion:function() {
          update()
        }
      })
    }
  })
  //})
}
function installTapped() {
  $device.taptic(2)
  $addin.save({
    name:$addin.current.name,
    data:updateData,
    handler:function(success) {
      if (success) {
        $addin.restart()
      }
    }
  })
}

function loadSettings() {
  releaseColorMode = $cache.get("releaseColorMode")
  reverseColorMode = $cache.get("reverseColorMode")
  boxVSshow = $cache.get("boxVSshow")
  stockMode = $cache.get("stockMode")
  console.log("SMsetting " + stockMode)
  let bvssl02font
  let rcmsl11color
  let rcmsl12color
  if (releaseColorMode) {
    rcmsl11color = $color("#FF9900")
    rcmsl12color = $color("#FF3B30")
  } else {
    rcmsl11color = $color("#888888")
    rcmsl12color = $color("#888888")
  }
  if (boxVSshow) {
    bvssl02font = $font("PingFangSC-Semibold",17)
  } else {
    bvssl02font = $font("PingFangSC-Light",17)
  }
  //$("settingList").data = {}
  let data = [
    {
      title: "主界面设置",
      rows: [
        {
          info:"",
          rcSetting:{
            hidden:false
          },
          releaseColorMode:{
            on:releaseColorMode
          },
          rcLabel11:{
            textColor:rcmsl11color
          },
          rcLabel12:{
            textColor:rcmsl12color
          }
        },
        {
          info:"",
          BvSsetting:{
            hidden:false
          },
          boxVSshow:{
            on:boxVSshow
          },
          BvSsLabel02:{
            font:bvssl02font
          }
        },
        {
          info:"",
          uniCell1:{
            hidden:false
          },
          uc1Title:{
            text:"股票模式"
          },
          uc1Subtitle:{
            text:"长按主界面 第三栏 和 最右一栏 可快速开关"
          },
          uc1Switch:{
            on:stockMode,
            info:"stockMode"
          }
        }
      ]
    },
    {
      title:"版本更新",
      rows:[
        {
          
        },
        {
          info:"checkUpdate",
          uniCell0:{hidden:false},
          uc0Title:{
            text:"检查更新",
            textColor:$color("#157EFB")
            },
          uc0Subtitle:{text:"当前版本：" + version},
          uc0Detail:{text:updateString}
        }
      ]
    },
    {
      title:"更多",
      rows:[
        
      ]
    }
   ]
   if (stockMode) {
     data[0].rows[3] = reverseColorSetting()
   }
   if (updateAvailable) {
     data[1].rows[2] = updateInfoCell()
   }
   $("settingList").data = data
   if (downloading) {
     setTimeout(progress,150)
    }
}
